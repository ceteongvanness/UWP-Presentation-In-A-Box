# CortanaAnniversaryEditionSample
Sample app showing some new features in the Anniversary Edition SDK
