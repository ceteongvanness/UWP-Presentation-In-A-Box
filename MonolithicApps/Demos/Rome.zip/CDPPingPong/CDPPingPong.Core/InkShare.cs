﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using Windows.ApplicationModel;
using Windows.ApplicationModel.Activation;
using Windows.ApplicationModel.AppService;
using Windows.ApplicationModel.Background;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.System.RemoteSystems;

namespace CDPPingPong.Core
{
    public static class InkShare
    {
        private static BackgroundTaskDeferral _serviceDeferral;
        public static event EventHandler<byte[]> OnUpdatedInkData;

        public static void OnRemoteInkReceived(BackgroundActivatedEventArgs args)
        {
            var taskInstance = args.TaskInstance;
            var details = taskInstance.TriggerDetails as AppServiceTriggerDetails;

            if (details != null && details.Name == "com.shawnhenry.inkshare")
            {
                //Take a service deferral so the service isn't terminated
                _serviceDeferral = taskInstance.GetDeferral();

                taskInstance.Canceled += TaskInstance_Canceled;


                //Listen for incoming app service requests
                details.AppServiceConnection.RequestReceived += AppServiceConnection_RequestReceived;
            }
        }

        private static readonly AppServiceConnection appServiceConnection = new AppServiceConnection();
        private static bool _serviceClosed = true;

        public static async void SendInkStrokes(byte[] inkData, RemoteSystem remoteSystem)
        {
            if (await InitAppServiceConnection(remoteSystem)) return;


            var valueSet = new ValueSet { ["InkData"] = inkData };

            AppServiceResponse response = await appServiceConnection.SendMessageAsync(valueSet);
            var ackString = response.Message["Ack"] as string;
            Debug.WriteLine("Ack: " + ackString);


        }

        private static IAsyncOperation<AppServiceConnectionStatus> _appServiceAsyncOperation;
        private static async Task<bool> InitAppServiceConnection(RemoteSystem remoteSystem)
        {
            if (_appServiceAsyncOperation != null && _appServiceAsyncOperation.Status == AsyncStatus.Started) //we're in the middle of connecting, so bail
                return true;

            if (_serviceClosed)
            {
                //Set up a new app service connection
                appServiceConnection.AppServiceName = "com.shawnhenry.inkshare";
                appServiceConnection.PackageFamilyName = Package.Current.Id.FamilyName;//"70709eb4-778d-4d57-bd17-d994a0b932ca_1mq6046wgx71r";
                //"fa42fe95-37a2-4500-ac99-040fff56ae93_1mq6046wgx71r";//Package.Current.Id.FamilyName;
                appServiceConnection.ServiceClosed += AppServiceConnection_ServiceClosed;

                RemoteSystemConnectionRequest connectionRequest = new RemoteSystemConnectionRequest(remoteSystem);
                _appServiceAsyncOperation = appServiceConnection.OpenRemoteAsync(connectionRequest);

                var status = await _appServiceAsyncOperation;
                switch (status)
                {
                    case AppServiceConnectionStatus.AppServiceUnavailable:
                        return true;
                    case AppServiceConnectionStatus.RemoteSystemUnavailable:
                        return true;
                    case AppServiceConnectionStatus.RemoteSystemNotSupportedByApp:
                        return true;
                    case AppServiceConnectionStatus.AppNotInstalled:
                        return true;
                    case AppServiceConnectionStatus.AppUnavailable:
                        return true;
                    case AppServiceConnectionStatus.Unknown:
                        return true;
                    case AppServiceConnectionStatus.NotAuthorized:
                        return true;
                }
                _serviceClosed = false;
            }
            return false;
        }

        private static void AppServiceConnection_ServiceClosed(AppServiceConnection sender, AppServiceClosedEventArgs args)
        {
            _serviceClosed = true;
        }

        private static void TaskInstance_Canceled(IBackgroundTaskInstance sender, BackgroundTaskCancellationReason reason)
        {
            if (_serviceDeferral != null)
            {
                //Complete the service deferral
                _serviceDeferral.Complete();
                _serviceDeferral = null;
            }
        }

        private static async void AppServiceConnection_RequestReceived(AppServiceConnection sender, AppServiceRequestReceivedEventArgs args)
        {
            //Get a deferral so we can use an awaitable API to respond to the message
            var messageDeferral = args.GetDeferral();

            var valueSet = args.Request.Message;
            var bytes = valueSet["InkData"] as byte[];
            OnUpdatedInkData?.Invoke(null, bytes);
            try
            {
                var result = new ValueSet {["Ack"] = "OK"};

                //Send the response
                await args.Request.SendResponseAsync(result);
            }
            finally
            {
                messageDeferral.Complete();
            }
        }
    }
}
