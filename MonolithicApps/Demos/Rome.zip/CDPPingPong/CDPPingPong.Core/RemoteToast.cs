﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.ApplicationModel;
using Windows.ApplicationModel.Activation;
using Windows.ApplicationModel.AppService;
using Windows.ApplicationModel.Background;
using Windows.Data.Xml.Dom;
using Windows.Foundation.Collections;
using Windows.System.RemoteSystems;
using Windows.UI.Notifications;

namespace CDPPingPong.Core
{
    public static class RemoteToast
    {
        private static BackgroundTaskDeferral _serviceDeferral;

        internal static async void Show(string toastXml, RemoteSystem remoteSystem)
        {
            using (var connection = new AppServiceConnection())
            {
                //Set up a new app service connection
                connection.AppServiceName = "com.shawnhenry.remotetoastservice";
                connection.PackageFamilyName = Package.Current.Id.FamilyName;

                //RemoteSystemConnectionRequest connectionRequest = new RemoteSystemConnectionRequest(remoteSystem);
                //var status = await connection.OpenRemoteAsync(connectionRequest);

                var status = await connection.OpenAsync();

                //If something went wrong. Lets figure out what it was and show the user a meaningful message and walk away
                switch (status)
                {
                    case AppServiceConnectionStatus.AppServiceUnavailable:
                        return;

                    case AppServiceConnectionStatus.RemoteSystemUnavailable:
                        return;
                    case AppServiceConnectionStatus.RemoteSystemNotSupportedByApp:
                        return;
                    case AppServiceConnectionStatus.AppNotInstalled:
                        return;
                }

                Debug.WriteLine("Sending xml: " + toastXml);

                var valueSet = new ValueSet { ["ToastXml"] = toastXml };

                AppServiceResponse response = await connection.SendMessageAsync(valueSet);
                var ackString = response.Message["Ack"] as string;
                Debug.WriteLine("Ack: " + ackString);

            }
        }

        public static void OnRemoteToastReceived(IBackgroundTaskInstance taskInstance)
        {
            var details = taskInstance.TriggerDetails as AppServiceTriggerDetails;

            if (details != null && details.Name == "com.shawnhenry.remotetoastservice")
            {
                //Take a service deferral so the service isn't terminated
                _serviceDeferral = taskInstance.GetDeferral();

                taskInstance.Canceled += TaskInstance_Canceled;


                //Listen for incoming app service requests
                details.AppServiceConnection.RequestReceived += AppServiceConnection_RequestReceived;
            }
        }

        public static void OnRemoteToastReceived(BackgroundActivatedEventArgs args)
        {
            var taskInstance = args.TaskInstance;
            OnRemoteToastReceived(taskInstance);

        }

        private static void TaskInstance_Canceled(IBackgroundTaskInstance sender, BackgroundTaskCancellationReason reason)
        {
            if (_serviceDeferral != null)
            {
                //Complete the service deferral
                _serviceDeferral.Complete();
                _serviceDeferral = null;
            }
        }

        private static async void AppServiceConnection_RequestReceived(AppServiceConnection sender, AppServiceRequestReceivedEventArgs args)
        {
            //Get a deferral so we can use an awaitable API to respond to the message
            var messageDeferral = args.GetDeferral();

            var valueSet = args.Request.Message;
            var toastXml = valueSet["ToastXml"] as string;

            if (toastXml != null)
            {
                var xmlDoc = new XmlDocument();
                xmlDoc.LoadXml(toastXml);
                ToastNotification notification = new ToastNotification(xmlDoc);
                ToastNotificationManager.CreateToastNotifier().Show(notification);
            }


            try
            {
                var result = new ValueSet { ["Ack"] = "OK" };

                //Send the response
                await args.Request.SendResponseAsync(result);
            }
            finally
            {
                messageDeferral.Complete();
            }
        }
    }
}
