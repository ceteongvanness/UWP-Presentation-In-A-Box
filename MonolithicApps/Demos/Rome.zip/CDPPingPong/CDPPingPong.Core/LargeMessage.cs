﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.Foundation.Collections;

namespace CDPPingPong.Core
{
    public sealed class LargeMessage
    {
        const string AllowedChars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz#@$^*()";
        private static Random rng = new Random();
        public static ValueSet CreateLargeMessage(int size)
        {

            char[] chars = new char[size];
            int setLength = AllowedChars.Length;
            for (int i = 0; i < size; ++i)
            {
                chars[i] = AllowedChars[rng.Next(setLength)];
            }


            var valueSet = new ValueSet
            {
                ["Type"] = "LargeMessage",
                ["CreationDate"] = DateTime.Now.ToString(CultureInfo.InvariantCulture),
                ["PayloadSize"] = size,
                ["Payload"] = new string(chars, 0, size),
            };


            return valueSet;

        }
    }
}
