﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using Windows.ApplicationModel;
using Windows.ApplicationModel.AppService;
using Windows.Foundation.Collections;
using Windows.System.RemoteSystems;
using System.Globalization;
using System.Linq;

namespace CDPPingPong.Core
{
    public sealed class PingPong
    {

        private static RemoteSystemWatcher _watcher;
        private static readonly List<RemoteSystem> RemoteSystemList = new List<RemoteSystem>();

        public static event EventHandler<RemoteSystem> OnRemoteDeviceAdded;
        public static event EventHandler<RemoteSystem> OnRemoteDeviceUpdated;
        public static event EventHandler<string> OnRemoteDeviceRemoved;

        public static event EventHandler<PingPongMessage> OnColdPongReceived;
        public static event EventHandler<PingPongMessage> OnWarmPongReceived;
        public static event EventHandler<string> OnStatusUpdateMessage;
        public static event EventHandler<string> OnErrorMessage;


        private static async void RequestAccess()
        {
            try
            {
                await RemoteSystem.RequestAccessAsync();

            }
            catch (Exception e)
            {

                Debug.WriteLine(e);
            }
        }

        public static RemoteSystemDiscoveryTypeFilter DiscoveryFilter = new RemoteSystemDiscoveryTypeFilter(RemoteSystemDiscoveryType.Any);
        public static RemoteSystemKindFilter KindFilter = null;


        private static List<IRemoteSystemFilter> BuildFilters()
        {
            var filters = new List<IRemoteSystemFilter> {DiscoveryFilter};


            if(KindFilter != null)
            {
                filters.Add(KindFilter);
            }

            var statusFilter = new RemoteSystemStatusTypeFilter(RemoteSystemStatusType.Any);
            filters.Add(statusFilter);

            var kindFilterString = KindFilter != null ? string.Join(",", KindFilter.RemoteSystemKinds.ToArray()) : string.Empty;
            DebugWrite($"RebuiltFilter: {DiscoveryFilter.RemoteSystemDiscoveryType} {statusFilter.RemoteSystemStatusType} {kindFilterString}");
            return filters;
        }

        public static void DiscoverDevices()
        {
            RequestAccess();

            //return;
            //await Task.Delay(1000);

            //Create Watcher for remote devices
            _watcher = RemoteSystem.CreateWatcher(BuildFilters());

            //Hook up event handlers
            _watcher.RemoteSystemAdded += _watcher_RemoteSystemAdded;
            _watcher.RemoteSystemRemoved += _watcher_RemoteSystemRemoved;
            _watcher.RemoteSystemUpdated += _watcher_RemoteSystemUpdated;

            //Start the Watcher
            _watcher.Start();
            Events.TrackEvent(Events.StartRemoteSystemWatcher);

        }

        private static void _watcher_RemoteSystemUpdated(RemoteSystemWatcher sender, RemoteSystemUpdatedEventArgs args)
        {
            //Remote and re-add remote system
            //var found = _remoteSystemList.FindAll(d => d.Id == args.RemoteSystem.Id);

            var remoteSystem = args.RemoteSystem;
            RemoteSystemList.RemoveAll(d => d.Id == remoteSystem.Id);
            RemoteSystemList.Add(remoteSystem);

            Events.TrackEvent(Events.RemoteSystemUpdated);

            DebugWrite(
                $"RemoteSystemUpdated: {remoteSystem.DisplayName} {remoteSystem.Id} {remoteSystem.IsAvailableByProximity} {remoteSystem.Kind} {remoteSystem.Status}");

            OnRemoteDeviceUpdated?.Invoke(null, remoteSystem);
        }

        private static void _watcher_RemoteSystemRemoved(RemoteSystemWatcher sender, RemoteSystemRemovedEventArgs args)
        {
            //Remove all remote systems with matching Ids
            RemoteSystemList.RemoveAll(d => d.Id == args.RemoteSystemId);
            Events.TrackEvent(Events.RemoteSystemRemoved);

            DebugWrite("RemoteSystemRemove: " + args.RemoteSystemId);
            OnRemoteDeviceRemoved?.Invoke(null, args.RemoteSystemId);

        }

        private static void _watcher_RemoteSystemAdded(RemoteSystemWatcher sender, RemoteSystemAddedEventArgs args)
        {
            var remoteSystem = args.RemoteSystem;
            Events.TrackEvent(Events.RemoteSystemAdded);

            RemoteSystemList.Add(remoteSystem);
            DebugWrite(
                $"RemoteSystemAdded: {remoteSystem.DisplayName} {remoteSystem.Id} {remoteSystem.IsAvailableByProximity} {remoteSystem.Kind} {remoteSystem.Status}");

            OnRemoteDeviceAdded?.Invoke(null, remoteSystem);

            SendPingPongMessage(remoteSystem);


        }

        public static void SendPingPongMessage(RemoteSystem remoteSystem)
        {
            SendMessage(remoteSystem, PingPongMessage.CreatePingCommand(remoteSystem).ToValueSet());
        }
        

        private static async void SendMessage(RemoteSystem remoteSystem, ValueSet valueSet)
        {
            using (var connection = new AppServiceConnection())
            {
                //Set up a new app service connection
                connection.AppServiceName = "com.microsoft.test.cdppingpongservice";
                connection.PackageFamilyName = Package.Current.Id.FamilyName;

                RemoteSystemConnectionRequest connectionRequest = new RemoteSystemConnectionRequest(remoteSystem);
                var status = await connection.OpenRemoteAsync(connectionRequest);

                //If something went wrong. Lets figure out what it was and show the user a meaningful message and walk away
                switch (status)
                {
                    case AppServiceConnectionStatus.AppServiceUnavailable:
                        DebugWrite(string.Format("The app AppServicesProvider is installed but it does not provide the app service {0}.", connection.AppServiceName));
                        return;
                    case AppServiceConnectionStatus.RemoteSystemUnavailable:
                        DebugWrite($"The remote system is unavailable ({remoteSystem.DisplayName}, {remoteSystem.Id}) ");
                        return;
                    case AppServiceConnectionStatus.RemoteSystemNotSupportedByApp:
                        DebugWrite($"The remote app does not support remote invocation ({remoteSystem.DisplayName}, {remoteSystem.Id})");
                        return;
                    case AppServiceConnectionStatus.AppNotInstalled:
                        DebugWrite($"The remote app is not installed ({remoteSystem.DisplayName}, {remoteSystem.Id})");
                        return;
                    case AppServiceConnectionStatus.AppUnavailable:
                        DebugWrite($"The remote app is not available ({remoteSystem.DisplayName}, {remoteSystem.Id})");
                        return;
                    case AppServiceConnectionStatus.Unknown:
                        DebugWrite($"Unknown AppServiceConnectionStatus ({remoteSystem.DisplayName}, {remoteSystem.Id})");
                        return;
                    case AppServiceConnectionStatus.NotAuthorized:
                        DebugWrite($"The remote app service connection is not authorized ({remoteSystem.DisplayName}, {remoteSystem.Id})");
                        return;
                    case AppServiceConnectionStatus.Success:
                        break;  
                    default:
                        throw new ArgumentOutOfRangeException();
                }


                AppServiceResponse response = await connection.SendMessageAsync(valueSet);

                if (response.Status == AppServiceResponseStatus.Success)
                {
                    var pongMessage = PingPongMessage.FromValueSet(response.Message);
                    OnColdPongReceived?.Invoke(null, pongMessage);

                    var roundTripTime = (DateTime.Now - pongMessage.CreationDate);
                    DebugWrite("Cold Pong received from " + pongMessage.TargetId + " with RTT: " + roundTripTime);
                    Events.TrackEvent(Events.CompletedColdPingEvent, roundTripTime);


                    response = await connection.SendMessageAsync(PingPongMessage.CreatePingCommand(remoteSystem).ToValueSet());
                    if (response.Status == AppServiceResponseStatus.Success)
                    {
                        pongMessage = PingPongMessage.FromValueSet(response.Message);
                        OnWarmPongReceived?.Invoke(null, pongMessage);

                        roundTripTime = (DateTime.Now - pongMessage.CreationDate);
                        DebugWrite("Warm Pong received from " + pongMessage.TargetId + " with RTT: " + roundTripTime);
                        Events.TrackEvent(Events.CompletedWarmPingEvent, roundTripTime);
                    }
                    return;
                }

                //If something went wrong. Lets figure out what it was and show the user a meaningful message and walk away
                switch (status)
                {
                    case AppServiceConnectionStatus.AppServiceUnavailable:
                        DebugWrite(string.Format("The app AppServicesProvider is installed but it does not provide the app service {0}.", connection.AppServiceName));
                        return;
                    case AppServiceConnectionStatus.RemoteSystemUnavailable:
                        DebugWrite($"The remote system is unavailable ({remoteSystem.DisplayName}, {remoteSystem.Id}) ");
                        return;
                    case AppServiceConnectionStatus.RemoteSystemNotSupportedByApp:
                        DebugWrite($"The remote app does not support remote invocation ({remoteSystem.DisplayName}, {remoteSystem.Id})");
                        return;
                    case AppServiceConnectionStatus.AppNotInstalled:
                        DebugWrite($"The remote app is not installed ({remoteSystem.DisplayName}, {remoteSystem.Id})");
                        return;
                    case AppServiceConnectionStatus.AppUnavailable:
                        DebugWrite($"The remote app is not available ({remoteSystem.DisplayName}, {remoteSystem.Id})");
                        return;
                    case AppServiceConnectionStatus.Unknown:
                        DebugWrite($"Unknown AppServiceConnectionStatus ({remoteSystem.DisplayName}, {remoteSystem.Id})");
                        return;
                    case AppServiceConnectionStatus.NotAuthorized:
                        DebugWrite($"The remote app service connection is not authorized ({remoteSystem.DisplayName}, {remoteSystem.Id})");
                        return;
                    case AppServiceConnectionStatus.Success:
                        break;
                    default:
                        throw new ArgumentOutOfRangeException();
                }
            }
        }

        private static void DebugWrite(string v)
        {
            Debug.WriteLine(v);
            OnStatusUpdateMessage?.Invoke(null, v);
        }

        private static void ErrorWrite(string v)
        {
            Debug.WriteLine(v);
            OnErrorMessage?.Invoke(null, v);
        }

        public static ValueSet HandleCommand(ValueSet message)
        {
            object typeObj;
            message.TryGetValue("Type", out typeObj);
            var type = typeObj as string;

            if (type == "ping")
            {
                return PingPongMessage.CreatePongCommand(PingPongMessage.FromValueSet(message)).ToValueSet();
            }
            else
            {
                return new ValueSet
                {
                    ["Type"] = "Ack", ["CreationDate"] = DateTime.Now.ToString(CultureInfo.InvariantCulture),
                };
            }
        }
    }
}
