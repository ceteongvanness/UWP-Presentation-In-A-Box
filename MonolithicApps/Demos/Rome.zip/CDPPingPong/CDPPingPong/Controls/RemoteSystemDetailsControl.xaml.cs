﻿using CDPPingPong.Core;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Threading.Tasks;
using Windows.ApplicationModel.DataTransfer;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Storage;
using Windows.Storage.FileProperties;
using Windows.System;
using Windows.System.RemoteSystems;
using Windows.UI.Input.Inking;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Media.Imaging;
using Windows.UI.Xaml.Navigation;

// The User Control item template is documented at http://go.microsoft.com/fwlink/?LinkId=234236

namespace CDPPingPong.Controls
{
    public sealed partial class RemoteSystemDetailsControl : UserControl
    {
        public RemoteSystemInfo SelectedSystem => DataContext as RemoteSystemInfo;

        public ObservableCollection<string> Suggestions = new ObservableCollection<string>(new string[]
        {
            "http://bing.com",
            "http://msn.com",
            "ms-windows-store://pdp/?productid=9NBLGGH4NNQJ",
            "spotify:artist:06HL4z0CvFAxyc27GXpf02"
        });


        public RemoteSystemDetailsControl()
        {
            this.InitializeComponent();
            UriSuggestTextBox.ItemsSource = Suggestions;

            InkDrawingAttributes drawingAttributes = new InkDrawingAttributes();
            drawingAttributes.Color = Windows.UI.Colors.CornflowerBlue;
            drawingAttributes.Size = new Size(5, 5);
            drawingAttributes.IgnorePressure = false;
            drawingAttributes.FitToCurve = true;

            InkCanvas.InkPresenter.UpdateDefaultDrawingAttributes(drawingAttributes);
            InkCanvas.InkPresenter.StrokesCollected += InkPresenter_StrokesCollected;
            InkCanvas.InkPresenter.InputDeviceTypes = Windows.UI.Core.CoreInputDeviceTypes.Mouse | Windows.UI.Core.CoreInputDeviceTypes.Pen | Windows.UI.Core.CoreInputDeviceTypes.Touch;

            PingPong.OnColdPongReceived += PingPong_OnColdPongReceived;
            PingPong.OnWarmPongReceived += PingPong_OnWarmPongReceived;

            this.DataContextChanged += RemoteSystemDetailsControl_DataContextChanged;
         }

        private async void PingPong_OnWarmPongReceived(object sender, PingPongMessage e)
        {
            await Dispatcher.RunAsync(Windows.UI.Core.CoreDispatcherPriority.Normal, () =>
            {
                if (SelectedSystem.Id == e.TargetId)
                {
                    SelectedSystem.WarmPingTime = e.RoundTripTime.TotalMilliseconds.ToString("0") + "ms";
                    Bindings.Update();
                }

            });
        }

        private async void PingPong_OnColdPongReceived(object sender, PingPongMessage e)
        {
            await Dispatcher.RunAsync(Windows.UI.Core.CoreDispatcherPriority.Normal, () =>
            {
                if (SelectedSystem.Id == e.TargetId)
                {
                    SelectedSystem.ColdPingTime = e.RoundTripTime.TotalMilliseconds.ToString("0") + "ms";
                    Bindings.Update();
                }


            });
        }

        private async void InkPresenter_StrokesCollected(Windows.UI.Input.Inking.InkPresenter sender, Windows.UI.Input.Inking.InkStrokesCollectedEventArgs args)
        {
            if (sender.StrokeContainer.GetStrokes().Count < 2) //launch the remote app on first stroke
            {
                await LaunchRemoteUriAsync(SelectedSystem?.RemoteSystem, new Uri("remote-ink-pad:pad"));
            }

            using (var memoryStream = new MemoryStream())
            {
                await InkCanvas.InkPresenter.StrokeContainer.SaveAsync(memoryStream.AsOutputStream());
                var result = memoryStream.ToArray();
                InkShare.SendInkStrokes(result, SelectedSystem?.RemoteSystem );
                memoryStream.Position = 0;
            }
        }

        private void RemoteSystemDetailsControl_DataContextChanged(FrameworkElement sender, DataContextChangedEventArgs args)
        {
            Bindings.Update();

     //       var system = args.NewValue as RemoteSystemInfo;
          //  system.PropertyChanged += System_PropertyChanged;
            
        }

        private void System_PropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            //throw new NotImplementedException();
        }

        private async void Button_Click(object sender, RoutedEventArgs e)
        {
            //var uri = new Uri("ms-windows-store://pdp/?productid=9NBLGGH4NNQJ");
            var uri = new Uri(UriSuggestTextBox.Text);
            var remoteSystem = SelectedSystem?.RemoteSystem;
            await LaunchRemoteUriAsync(remoteSystem, uri);
        }

        private static async Task LaunchRemoteUriAsync(RemoteSystem remoteSystem, Uri uri)
        {
            if (remoteSystem != null)
            {
                var connection = new RemoteSystemConnectionRequest(remoteSystem);

                Events.TrackEvent(Events.LaunchUriAsyncStart);
                var result = await RemoteLauncher.LaunchUriAsync(connection, uri);

                if (result == RemoteLaunchUriStatus.Success)
                {
                    Events.TrackEvent(Events.LaunchUriAsyncSuccess);
                }
                switch (result)
                {
                    case RemoteLaunchUriStatus.Success:
                        Events.TrackEvent(Events.LaunchUriAsyncSuccess);
                        break;
                    case RemoteLaunchUriStatus.DeniedByRemoteSystem:
                        Events.TrackEvent(Events.LaunchUriAsyncErrorDeniedByRemoteSystem);
                        break;
                    case RemoteLaunchUriStatus.ProtocolUnavailable:
                        Events.TrackEvent(Events.LaunchUriAsyncErrorProtocolUnavailable);
                        break;
                    case RemoteLaunchUriStatus.RemoteSystemUnavailable:
                        Events.TrackEvent(Events.LaunchUriAsyncErrorRemoteSystemUnavailable);
                        break;
                    default:
                        Events.TrackEvent(Events.LaunchUriAsyncErrorOther);
                        break;
                }
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            var remoteSystem = SelectedSystem?.RemoteSystem;

            if (remoteSystem != null)
            {
                PingPong.SendPingPongMessage(remoteSystem);

                //PingPong.SendLargeMessage(remoteSystem);
            }
        }

        private void UriSuggestTextBox_OnGotFocus(object sender, RoutedEventArgs e)
        {
            UriSuggestTextBox.IsSuggestionListOpen = true;

        }

        private async void ClearButton_OnClick(object sender, RoutedEventArgs e)
        {
            InkCanvas.InkPresenter.StrokeContainer.Clear();

            using (var memoryStream = new MemoryStream())
            {
                await InkCanvas.InkPresenter.StrokeContainer.SaveAsync(memoryStream.AsOutputStream());
                var result = memoryStream.ToArray();
                InkShare.SendInkStrokes(result, SelectedSystem?.RemoteSystem);
                memoryStream.Position = 0;
            }
        }

        private void FileTransferDragAndDrop_OnDragOver(object sender, DragEventArgs e)
        {
            //throw new NotImplementedException();
            Debug.WriteLine("OnDragOver");
            e.AcceptedOperation = DataPackageOperation.Copy;
        }

        private async void FileTransferDragAndDrop_OnDrop(object sender, DragEventArgs e)
        {
            Debug.WriteLine("OnDrop");
            if (e.DataView.Contains(StandardDataFormats.StorageItems))
            {
                var storageItems = await e.DataView.GetStorageItemsAsync();

                foreach (StorageFile storageItem in storageItems)
                {
                    var bitmapImage = new BitmapImage();
                    //await bitmapImage.SetSourceAsync(await e.DataView.Properties.Thumbnail.OpenReadAsync());
                    await bitmapImage.SetSourceAsync(await storageItem.GetThumbnailAsync(ThumbnailMode.SingleItem));
                    ulong fileSize = (await storageItem.GetBasicPropertiesAsync()).Size;

                    //var shareItem = new ShareItem
                    //{
                    //    Id = Guid.NewGuid(),
                    //    Name = storageItem.DisplayName,
                    //    Path = Path.GetFileName(storageItem.Path),
                    //    Size = fileSize / 1024 + " KB",
                    //    Image = bitmapImage,
                    //    StorageItem = storageItem
                    //};

                    //this.ShareItems.Add(shareItem);

                }

            }

            //throw new NotImplementedException();
        }

        private void FileTransferDragAndDrop_OnDragLeave(object sender, DragEventArgs e)
        {
            Debug.WriteLine("OnDragLeave");
            FileTransferDragAndDrop.Background =
    Application.Current.Resources["SystemControlBackgroundChromeMediumBrush"] as SolidColorBrush;

            //throw new NotImplementedException();
        }

        private void FileTransferDragAndDrop_OnDragEnter(object sender, DragEventArgs e)
        {
            Debug.WriteLine("OnDragEnter");
            FileTransferDragAndDrop.Background =
                Application.Current.Resources["SystemControlBackgroundBaseMediumLowBrush"] as SolidColorBrush;

        }
    }
}
