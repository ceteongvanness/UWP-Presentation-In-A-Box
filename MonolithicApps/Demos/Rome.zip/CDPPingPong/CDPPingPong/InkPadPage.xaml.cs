﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.ApplicationModel;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Input.Inking;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using CDPPingPong.Core;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234238

namespace CDPPingPong
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class InkPadPage : Page
    {
        public InkPadPage()
        {
            this.InitializeComponent();
            InkDrawingAttributes drawingAttributes = new InkDrawingAttributes();
            drawingAttributes.Color = Windows.UI.Colors.Red;
            drawingAttributes.Size = new Size(5, 5);
            drawingAttributes.IgnorePressure = false;
            drawingAttributes.FitToCurve = true;

            InkCanvas.InkPresenter.UpdateDefaultDrawingAttributes(drawingAttributes);
            InkCanvas.InkPresenter.InputDeviceTypes = Windows.UI.Core.CoreInputDeviceTypes.Mouse | Windows.UI.Core.CoreInputDeviceTypes.Pen;
            InkShare.OnUpdatedInkData += InkShare_OnUpdatedInkData;
        }

        private async void InkShare_OnUpdatedInkData(object sender, byte[] e)
        {
            await Dispatcher.RunAsync(Windows.UI.Core.CoreDispatcherPriority.Normal, async () =>
            {
                using (var memoryStream = new MemoryStream(e))
                {
                    //inkCanvas2.InkPresenter.StrokeContainer.Clear();
                    memoryStream.Position = 0;
                    await InkCanvas.InkPresenter.StrokeContainer.LoadAsync(memoryStream.AsInputStream());
                }
            });

        }
    }
}
