﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.ApplicationModel.AppService;
using Windows.ApplicationModel.Background;
using CDPPingPong.Core;

namespace BackgroundTasks
{
    class RemoteToastTask : IBackgroundTask
    { 

        public void Run(IBackgroundTaskInstance taskInstance)
        {

            RemoteToast.OnRemoteToastReceived(taskInstance);
        }


    }
}
