//
//  ViewController.h
//  Calculator
//
//  Created by Nicholas Gerard on 1/25/16.
//  Copyright © 2016 Microsoft. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

